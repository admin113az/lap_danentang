class Question {
  late String questionText;
  late String questionAnswer;

  Question(String a, String b) {
    questionText = a;
    questionAnswer = b;
  }
}
