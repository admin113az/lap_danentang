class Answer {
  late String answerA;
  late String answerB;

  Answer(String a, String b) {
    answerA = a;
    answerB = b;
  }
}
