class Question {
  late String questionText;
  late bool questionAnswer;

  Question(String a, bool b) {
    questionText = a;
    questionAnswer = b;
  }
}
